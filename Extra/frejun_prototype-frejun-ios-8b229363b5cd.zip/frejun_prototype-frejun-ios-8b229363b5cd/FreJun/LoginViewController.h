//
//  LoginViewController.h
//  FreJun
//
//  Created by Shubham Sorte on 20/07/16.
//  Copyright © 2016 Shubham Sorte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Google/SignIn.h>

@interface LoginViewController : UIViewController <GIDSignInUIDelegate,GIDSignInDelegate>

- (IBAction)signInButtonPressed:(id)sender;

@end
